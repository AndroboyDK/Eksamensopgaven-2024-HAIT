
1) Remember to have the env.developement file in the all AllCodeInside -> It can be downloaded from here (perm required): 

2) Change directory to "AllCodeInside" then enter 'npm start' in the command line.

3) Open the ur browser and type in http://localhost:3000/usersFront/login.html

1. Note: 
Some functions depend on the geolocation api in the browser, therfore u should have a browser compatible with it and allow the website to acces ur location. 

2. Note: 
The app wont run if u have something running on port 3000, therfore turn that off or change the port in the server.js file. 